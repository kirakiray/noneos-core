export const RESET_PATH = Symbol("resetPath");

// 标记句柄来自 open()（用户通过系统选择器挑选的本地目录）。
// 这类句柄在 mount() 之前 path 只是光秃秃的目录名，无法通过 get() 还原，
// 因此不可被持久化（如存入 nos/storage）。子孙句柄通过 root 继承该标记。
// 用 Symbol.for 注册为全局符号，使 nos/storage 等模块无需 import 本文件即可读取，
// 避免为了一个常量而牵连加载整个 fs 模块（本文件顶层会创建 BroadcastChannel）。
export const PICKED = Symbol.for("nos-fs-picked");

export class PublicBaseHandle {
  #parent;
  #root;
  constructor(options) {
    this.#parent = options.parent;
    this.#root = options.root;
  }

  get parent() {
    return this.#parent;
  }

  get root() {
    return this.#root || this;
  }

  get path() {
    if (this[RESET_PATH]) {
      return this[RESET_PATH];
    }

    if (this.parent) {
      return `${this.parent.path}/${this.name}`;
    }

    return this.name;
  }

  async copyTo(targetHandle, name) {
    if (typeof targetHandle !== "string" && (await this.isSame(targetHandle))) {
      return this;
    }
    const [finalTarget, finalName] = await resolveTargetAndName(
      targetHandle,
      name,
      "copy",
      this,
    );

    // 如果是文件，直接复制文件内容
    if (this.kind === "file") {
      const newHandle = await finalTarget.get(finalName, {
        create: "file",
      });
      await newHandle.write(await this.file());

      return newHandle;
    }

    // 创建目标目录
    const newDir = await finalTarget.get(finalName, {
      create: "dir",
    });

    // 递归复制所有子文件和子目录
    for await (const [entryName, entry] of this.entries()) {
      await entry.copyTo(newDir, entryName);
    }

    return newDir;
  }

  async moveTo(targetHandle, name) {
    if (typeof targetHandle !== "string" && (await this.isSame(targetHandle))) {
      return this;
    }
    const [finalTarget, finalName] = await resolveTargetAndName(
      targetHandle,
      name,
      "move",
      this,
    );

    // 如果是文件，直接移动文件
    if (this.kind === "file") {
      const newHandle = await finalTarget.get(finalName, {
        create: "file",
      });
      await newHandle.write(await this.file());
      await this.remove();
      return newHandle;
    }

    // 如果是目录，先创建新目录
    const newDir = await finalTarget.get(finalName, {
      create: "dir",
    });

    // 递归移动所有子文件和子目录
    for await (const [entryName, entry] of this.entries()) {
      await entry.moveTo(newDir, entryName);
    }

    // 删除原目录
    await this.remove();

    return newDir;
  }

  toJSON() {
    return {
      name: this.name,
      path: this.path,
      kind: this.kind,
    };
  }

  // 监听文件系统变化
  async observe(func) {
    if (!!window.FileSystemObserver) {
      // 未来可能的API（提案阶段）
      const observer = new FileSystemObserver((records) => {
        for (const record of records) {
          console.log(`record: `, record);
          const path =
            this.path + "/" + record.relativePathComponents.join("/");

          if (record.type === "appeared") {
            continue;
          }

          let type;

          switch (record.type) {
            // case "appeared":
            //   type = "create";
            //   break;
            case "disappeared":
              type = "remove";
              break;
            case "modified":
              type = "write";
              break;
          }

          func({
            type,
            path,
          });
        }

        // func();
      });

      // 监听目录
      await observer.observe(this._handle, {
        recursive: true,
      });

      return () => {
        observer.disconnect();
      };
    }

    const obj = {
      func,
      handle: this,
    };

    observers.add(obj);

    return () => {
      observers.delete(obj);
    };
  }
}

// 监听文件系统变化
const castChannel = new BroadcastChannel("nonefs-system-handle-change");
castChannel.onmessage = (event) => {
  // 通知所有的观察者
  notify(
    {
      ...event.data,
    },
    true,
  );
};

// 观察者集合
const observers = new Set();

// 文件发生变动，就除法这个方法，通知所有的观察者
export const notify = ({ path, ...others }, isCast) => {
  if (!isCast) {
    // 通知其他标签页的文件系统变化
    castChannel.postMessage({
      path,
      ...others,
    });
  }

  observers.forEach((observer) => {
    // 只通知当前目录下或文件的观察者
    if (path.includes(observer.handle.path)) {
      observer.func({
        path,
        ...others,
      });
    }
  });
};

// 处理目标路径和文件名
const resolveTargetAndName = async (targetHandle, name, methodName, self) => {
  // 处理第一个参数为字符串的情况
  let finalTarget = targetHandle;
  let finalName = name;

  if (typeof targetHandle === "string") {
    finalName = targetHandle;
    finalTarget = self.parent;
  }
  // 检查目标路径是否为当前路径的子目录
  const targetPath = finalTarget.path;
  const currentPath = self.path;
  if (targetPath.startsWith(currentPath + "/")) {
    throw new Error(`Cannot ${methodName} a directory into its subdirectory`);
  }

  // 获取目标文件名，如果没有提供则使用原文件名
  finalName = finalName || self.name;

  return [finalTarget, finalName];
};
