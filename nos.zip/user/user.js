import { BaseUser } from "./base-user.js";
import {
  getUserKeys,
  saveUserKeys,
  saveUserInfo,
  getUserInfo,
  addUserStorageId,
  addSharedStorage,
  removeSharedStorage,
  getSharedStorages,
} from "./db.js";
import { getStorage as getGlobalStorage } from "../storage/main.js";
import { generateKeyPair } from "../crypto/crypto-ecdsa.js";
import { CredentialManager, PROFILE_ROLE } from "./cred.js";
import { ServerManager } from "./server.js";
import { RemoteUser } from "./remote-user.js";
import { RTCManager } from "./rtc.js";
import { ServiceRegistry } from "./service-registry.js";
import { TrafficLogger, inferCategory, measureSize } from "./traffic.js";
import { DedupCache } from "./reliable.js";

// 全局初始化 Promise 缓存，防止同一 namespace 并发初始化
const initPromises = new Map();

// 远端共享存储一期放行的只读操作子集（入站 __storage_req 的 op 白名单）。
// 写操作（setItem/removeItem/clear 等）一律拒绝，保证共享出去的空间只读。
const SHARED_STORAGE_READ_OPS = [
  "getItem",
  "has",
  "key",
  "length",
  "keys",
  "entries",
];

// 共享存储回传大小上限（字节）。中继服务器对单条文本消息硬限制 256KB
// （server/handshake/src/config.rs 的 text_message_max_size），超限响应会被服务器
// 直接拒绝且无法送达——对端已执行操作却收不到回包，只能干等超时。
// 因此回传前先测量完整 resp 的字节数，超限改回 too_large 错误，让请求端
// 立刻得到明确失败而不是超时。
const SHARED_STORAGE_RESP_MAX_BYTES = 256 * 1024;

/**
 * 本地用户类，继承自 BaseUser
 * 根据传入的命名空间在 IndexedDB 中管理公钥和私钥
 */
export class LocalUser extends BaseUser {
  #namespace;
  #sessionId = "s-" + Math.random().toString(36).substring(2, 10);
  #cred;
  #server;
  #rtc;
  #sessionChannel;
  #remoteUserCache = new Map(); // userId -> Promise<RemoteUser> | RemoteUser
  #serviceRegistry;
  #traffic;
  // 核心层消息去重：按 (fromUserId|msgId) 拦截重发，保证 __app handler 只执行一次
  #msgDedup = new DedupCache(4096);
  // ───── 接收端按序重排（与 RemoteUser 的 __wseq 线路序号配对）─────
  // `${fromUserId}|${fromSessionId}` -> { fromUserId, fromSessionId,
  //   next, buffer: Map<wseq, {messageData, viaServer}>, timer }
  // 跨路径（中继→RTC 切换）时事件到达顺序不可靠，此处按发送端在
  // 发送闸门内分配的 __wseq 恢复发送顺序后分发
  #orderStates = new Map();
  // 缺口等待上限：前序消息大概率仍在途（中继尾包），超时视为已随
  // 断开的连接丢失（发送端离线队列补投携带新序号，且有 msgId 去重兜底）
  #ORDER_HOLD_MS = 200;
  // 状态表容量上限：超限先清理空闲条目（buffer 空且无定时器），
  // 清理后该流下一条消息会以当前序号重建基线，不影响后续保序
  #ORDER_STATES_MAX = 512;
  // 惰性创建的大 payload 拉取发布器（阶段三第 9 步，见 _getDataPublisher）
  #dataPublisher = null;

  /**
   * 构造函数
   * @param {string} namespace - 用户空间的命名
   */
  constructor(namespace) {
    super(); // 初始化父类，由于我们修改了 BaseUser，可以不传 publicKey
    if (!namespace) {
      throw new Error("namespace is required");
    }
    this.#namespace = namespace;
    this.#cred = new CredentialManager(this);
    this.#server = new ServerManager(this);
    this.#rtc = new RTCManager(this);
    this.#serviceRegistry = new ServiceRegistry(this);
    this.#traffic = new TrafficLogger(this);
    // 创建持久化的 BroadcastChannel 监听跨标签页 session 查询
    this.#sessionChannel = new BroadcastChannel(`noneos-sessions-${namespace}`);
    this.#sessionChannel.addEventListener("message", (event) => {
      if (event.data.type === "session-announce") {
        // 其他标签页请求广播，回复自己的 sessionId
        this.#sessionChannel.postMessage({
          type: "session-response",
          sessionId: this.#sessionId,
        });
      }
    });

    // 设置 RTC 直连消息并分发给对应的 RemoteUser 实例
    this.#setupRTCDispatch();
    // 监听 relay 消息并分发给对应的 RemoteUser 实例
    this.#setupRelayDispatch();
    // 监听 RTC 建立/断开事件，触发对应 RemoteUser 重新测量 RTT
    this.#setupRTCStateListener();

    // 服务器恢复连接时，冲刷所有 RemoteUser 的离线队列（可靠投递补投）
    this.bind("server_connected", () => {
      // 重连后服务器侧会话是全新的，重新上报公开服务列表（exposeToServer）
      this.#serviceRegistry._resyncToServer();
      for (const remoteUser of this.remoteUsers) {
        remoteUser._flushQueue().catch(() => {});
      }
    });
  }

  /**
   * 设置 relay 消息分发：当本地用户收到 relay 消息时，
   * 解析后分发给缓存的 RemoteUser 实例。
   *
   * 支持两种 relay 格式：
   * - 文本 relay：JSON 格式，用于明文消息和内部协议（个人资料交换等）
   * - 二进制 relay：帧格式 [4B header_len][header JSON][payload]，用于 E2EE 加密数据
   *
   * E2EE 数据自动尝试解密，解密失败则透传原始 Uint8Array。
   */
  #setupRelayDispatch() {
    this.bind("message", (event) => {
      const detail = event.detail;
      // 入站流量埋点：服务器中继（含握手挑战、latency、relay 等所有 WS 文本/二进制）
      this.#recordInboundFromServer(detail);
      if (typeof detail.data === "string") {
        this.#handleTextRelay(detail, event);
      } else {
        this.#handleBinaryRelay(detail);
      }
    });
  }

  /**
   * 记录来自 WebSocket 服务器的入站流量元数据
   */
  #recordInboundFromServer(detail) {
    try {
      const url = detail.url || "";
      const size = measureSize(detail.data);
      let parsed = null;
      let peerUserId = "";
      let sessionId = "";
      if (typeof detail.data === "string") {
        try {
          parsed = JSON.parse(detail.data);
        } catch {
          parsed = null;
        }
        if (parsed && typeof parsed === "object") {
          // relay 消息内含 from_user_id/from_session_id
          if (parsed.type === "relay") {
            peerUserId = parsed.from_user_id || "";
            sessionId = parsed.from_session_id || "";
            const inner = parsed.data;
            const info = inferCategory(inner);
            this.#traffic.record({
              direction: "in",
              via: "server",
              serverUrl: url,
              peerUserId,
              sessionId,
              size,
              category: info.category,
              messageType: info.messageType,
              appId: info.appId,
              success: true,
            });
            return;
          }
          const info = inferCategory(parsed);
          this.#traffic.record({
            direction: "in",
            via: "server",
            serverUrl: url,
            peerUserId: "",
            sessionId: "",
            size,
            category: info.category,
            messageType: info.messageType,
            appId: info.appId,
            success: true,
          });
          return;
        }
      }
      // 二进制帧：尝试解析 header 获取 peerUserId/appId
      let category = "relay";
      let messageType = "relay";
      let appId = "";
      if (detail.data instanceof ArrayBuffer || ArrayBuffer.isView(detail.data)) {
        const buf =
          detail.data instanceof ArrayBuffer
            ? detail.data
            : detail.data.buffer.slice(
                detail.data.byteOffset,
                detail.data.byteOffset + detail.data.byteLength,
              );
        try {
          if (buf.byteLength >= 4) {
            const view = new DataView(buf);
            const headerLen = view.getUint32(0, false);
            if (4 + headerLen <= buf.byteLength) {
              const headerBytes = new Uint8Array(buf, 4, headerLen);
              const header = JSON.parse(new TextDecoder().decode(headerBytes));
              if (header && typeof header === "object") {
                peerUserId = header.from_user_id || "";
                sessionId = header.from_session_id || "";
                if (header.__app) {
                  category = "app";
                  messageType = "__app";
                  appId = header.__app;
                }
              }
            }
          }
        } catch {
          // 解析失败保持 relay
        }
      }
      this.#traffic.record({
        direction: "in",
        via: "server",
        serverUrl: url,
        peerUserId,
        sessionId,
        size,
        category,
        messageType,
        appId,
        success: true,
      });
    } catch (err) {
      // 记录失败不影响业务
      console.warn("[TrafficLogger] record inbound server failed:", err);
    }
  }

  /**
   * 处理文本 relay 消息（明文或内部协议）
   */
  #handleTextRelay(detail, event) {
    let parsed;
    try {
      parsed = JSON.parse(detail.data);
    } catch {
      return;
    }
    if (parsed.type !== "relay") return;
    const fromUserId = parsed.from_user_id;
    if (!fromUserId) return;

    // 拦截 RTC 信令，交由 RTCManager 处理，不透传给 RemoteUser
    // 同时阻止外部 message 监听器收到内部信令
    if (parsed.data?.type === "rtc_signal") {
      console.log(
        `[LocalUser] rtc_signal recv: from=${fromUserId}:${parsed.from_session_id}, signalType=${parsed.data.signal?.type}`,
      );
      event.stopImmediatePropagation();
      this.#rtc.handleSignal(
        fromUserId,
        parsed.from_session_id,
        parsed.data.signal,
      );
      return;
    }

    this.#dispatchToRemote(fromUserId, parsed.from_session_id, parsed.data, detail.url);
  }

  /**
   * 设置 RTC 直连消息分发：收到 DataChannel 消息后，
   * 尝试 E2EE 解密，然后分发给对应的 RemoteUser 实例。
   */
  #setupRTCDispatch() {
    this.bind("rtc_message", async (event) => {
      const { fromUserId, fromSessionId, data } = event.detail;
      // 入站流量埋点：RTC DataChannel（记录链路字节数，加密后）
      try {
        const size = measureSize(data);
        let category = "relay";
        let messageType = "relay";
        let appId = "";
        if (typeof data === "string") {
          try {
            const parsed = JSON.parse(data);
            const info = inferCategory(parsed);
            category = info.category;
            messageType = info.messageType;
            appId = info.appId;
          } catch {
            // 非 JSON 文本
          }
        }
        this.#traffic.record({
          direction: "in",
          via: "rtc",
          serverUrl: "",
          peerUserId: fromUserId || "",
          sessionId: fromSessionId || "",
          size,
          category,
          messageType,
          appId,
          success: true,
        });
      } catch {
        // 记录失败静默
      }

      let messageData = data;

      if (data instanceof ArrayBuffer || ArrayBuffer.isView(data)) {
        const buffer =
          data instanceof ArrayBuffer
            ? new Uint8Array(data)
            : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);

        if (buffer.byteLength > 12) {
          try {
            const { tryDecryptBinary } = await import(
              "../crypto/crypto-e2ee.js"
            );
            const decrypted = await tryDecryptBinary(
              this,
              fromUserId,
              buffer,
            );
            if (decrypted !== null) {
              messageData = decrypted;
            }
          } catch {
            // 解密失败，透传原始数据
          }
        }
      }

      // RTC DataChannel 传输的未加密消息为 JSON 字符串，
      // 需要 parse 成对象后才能被 #dispatchToRemote 正确路由（如 __app 分发）
      if (typeof messageData === "string") {
        try {
          messageData = JSON.parse(messageData);
        } catch {
          // 非 JSON 文本，保持原样透传
        }
      }

      this.#dispatchToRemote(fromUserId, fromSessionId, messageData, "rtc");
    });
  }

  /**
   * 监听 RTC 状态变化：
   * - connected：DataChannel 建立，重新测量 RTT
   * - disconnected：DataChannel/PC 断开，清理 RemoteUser 的重连标记与冷却，
   *   使下一次 send() 能重新发起 RTC 配对（避免刷新/抖动后永久走服务端中转）
   */
  #setupRTCStateListener() {
    this.bind("rtc_state", (event) => {
      const { userId, sessionId, state } = event.detail;
      console.log(
        `[LocalUser] rtc_state event: userId=${userId}, sessionId=${sessionId}, state=${state}, hasRemoteUser=${this.#remoteUserCache.has(userId)}`,
      );
      if (!this.#remoteUserCache.has(userId)) return;
      Promise.resolve(this.#remoteUserCache.get(userId))
        .then((remoteUser) => {
          if (state === "disconnected") {
            remoteUser._handleRTCStateChange(sessionId, "disconnected");
          }
          if (state === "connected") {
            // RTC 通道建立：尝试补投该对端的离线队列
            remoteUser._flushQueue().catch(() => {});
          }
          // connected / disconnected 都重测 RTT：
          // connected → 测新路径；disconnected → ping 自动回落到 server 路径
          remoteUser.recalcRTT(sessionId);
        })
        .catch((err) => {
          console.warn(
            `[LocalUser] rtc_state handler failed: userId=${userId}, sessionId=${sessionId}`,
            err,
          );
        });
    });
  }

  /**
   * 处理二进制 relay 帧
   *
   * 帧格式：[4B header_len(u32 BE)][header JSON][payload bytes]
   * 如果 payload 是 E2EE 格式（长度 > 12），自动尝试解密。
   */
  async #handleBinaryRelay(detail) {
    let buffer;
    try {
      buffer = detail.data instanceof Blob ? await detail.data.arrayBuffer() : detail.data;
    } catch {
      return;
    }

    if (buffer.byteLength < 4) return;
    const view = new DataView(buffer);
    const headerLen = view.getUint32(0, false); // BE

    if (4 + headerLen > buffer.byteLength) return;

    let header;
    try {
      const headerBytes = new Uint8Array(buffer, 4, headerLen);
      header = JSON.parse(new TextDecoder().decode(headerBytes));
    } catch {
      return;
    }

    if (header.type !== "relay") return;
    const fromUserId = header.from_user_id;
    if (!fromUserId) return;

    // 提取 payload 字节
    const payload = new Uint8Array(buffer, 4 + headerLen);

    // 尝试 E2EE 解密
    let messageData = payload;
    if (payload.byteLength > 12) {
      try {
        const { tryDecryptBinary } = await import("../crypto/crypto-e2ee.js");
        const decrypted = await tryDecryptBinary(this, fromUserId, payload);
        if (decrypted !== null) {
          messageData = decrypted;
        }
      } catch {
        // 解密失败，透传原始 payload
      }
    }

    this.#dispatchToRemote(fromUserId, header.from_session_id, messageData, detail.url);
  }

  /**
   * 将消息分发给相应的处理器
   *
   * 分发优先级：
   * 1. 若消息 type 为 __service_query → LocalUser 级别处理（回复 service 列表）
   * 1.5 若消息 type 为 __storage_req → 远端共享存储只读请求，本地校验执行并回传
   * 2. 若消息 type 为 __service_available / __service_unavailable → 更新对端 RemoteUser 的服务缓存
   * 3. 若消息包含 __app 字段 → 分发给 ServiceRegistry 中对应的 handler
   * 4. 否则 → 分发给缓存的 RemoteUser 实例
   */
  #dispatchToRemote(fromUserId, fromSessionId, messageData, viaServer) {
    // 1. 检查是否为 __service 发现协议消息（任何用户都可能发起，无需缓存）
    if (messageData && typeof messageData === "object" && messageData.type === "__service_query") {
      this.#handleServiceQuery(fromUserId, fromSessionId, messageData);
      return;
    }

    // 1.5 拦截远端共享存储只读请求（__storage_req）：本地校验并执行，回传结果
    if (
      messageData &&
      typeof messageData === "object" &&
      messageData.type === "__storage_req"
    ) {
      this.#handleStorageRequest(fromUserId, fromSessionId, messageData);
      return;
    }

    // 2. 检查是否为 __service_available / __service_unavailable 主动广播
    if (
      messageData &&
      typeof messageData === "object" &&
      (messageData.type === "__service_available" ||
        messageData.type === "__service_unavailable")
    ) {
      this.#handleServiceAvailability(
        fromUserId,
        fromSessionId,
        messageData.appId,
        messageData.type === "__service_available",
      );
      return;
    }

    // 3 / 4. 应用与数据消息：__env 信封消息（sendToService 通道）按 __wseq 重排后分发。
    // 中继→RTC 切换瞬间，两条通道的消息可能交错到达（服务器回执只代表
    // 消息进入对端写队列；接收端解析/解密管线也各自异步），到达顺序
    // 不可靠。携带 __wseq 的消息按发送顺序恢复后分发；未携带的
    // （旧版对端 / 裸 send() 数据报）保持原行为直发、不承诺跨路径有序。
    const wseq =
      messageData &&
      typeof messageData === "object" &&
      !Array.isArray(messageData)
        ? messageData.__wseq
        : undefined;
    if (Number.isInteger(wseq)) {
      delete messageData.__wseq; // 应用侧不可见
      this.#reorderDispatch(fromUserId, fromSessionId, wseq, messageData, viaServer);
      return;
    }

    this.#dispatchOrdered(fromUserId, fromSessionId, messageData, viaServer);
  }

  /**
   * 按 __wseq 重排分发：序号连续则立即按序分发；出现缺口时暂存并
   * 限时等待在途消息补齐（#ORDER_HOLD_MS），超时按序放出已缓存消息
   * 并越过缺口（缺口消息若真丢失，发送端离线队列会补投且被 msgId 去重）。
   */
  #reorderDispatch(fromUserId, fromSessionId, wseq, messageData, viaServer) {
    const key = `${fromUserId}|${fromSessionId}`;
    let st = this.#orderStates.get(key);
    if (!st) {
      st = {
        fromUserId,
        fromSessionId,
        next: wseq, // 首见序号即基线（发送端序号从 1 起，旧消息不会早于首见）
        buffer: new Map(),
        timer: null,
      };
      this.#orderStates.set(key, st);
      if (this.#orderStates.size > this.#ORDER_STATES_MAX) {
        this.#pruneOrderStates();
      }
    }

    if (wseq < st.next) {
      // 缺口超时后迟到的在途消息：直接分发而非丢弃——它只是拥堵超过
      // 了等待上限，仍在送达途中，丢弃等于静默丢数据。此处允许这一条
      // 失序；重复执行由 __env 的 msgId 去重兜底
      this.#dispatchOrdered(fromUserId, fromSessionId, messageData, viaServer);
      return;
    }

    if (wseq > st.next) {
      // 前序消息仍在途：暂存等待补齐
      st.buffer.set(wseq, { messageData, viaServer });
      if (!st.timer) {
        st.timer = setTimeout(() => {
          st.timer = null;
          this.#flushOrderBuffer(key);
        }, this.#ORDER_HOLD_MS);
      }
      return;
    }

    this.#dispatchOrdered(fromUserId, fromSessionId, messageData, viaServer);
    st.next++;
    // 连续段一次性放行
    while (st.buffer.size > 0) {
      const hit = st.buffer.get(st.next);
      if (!hit) break;
      st.buffer.delete(st.next);
      st.next++;
      this.#dispatchOrdered(
        st.fromUserId,
        st.fromSessionId,
        hit.messageData,
        hit.viaServer,
      );
    }
    if (st.buffer.size === 0 && st.timer) {
      clearTimeout(st.timer);
      st.timer = null;
    }
  }

  /**
   * 缺口超时：按序号放出全部缓存消息并越过缺口。
   * 触发条件是前序消息在时限内未到——大概率随断开的连接丢失；
   * 发送端的离线队列补投会携带新的线路序号，并有 msgId 去重防重复执行。
   */
  #flushOrderBuffer(key) {
    const st = this.#orderStates.get(key);
    if (!st || st.buffer.size === 0) return;
    const seqs = [...st.buffer.keys()].sort((a, b) => a - b);
    for (const seq of seqs) {
      if (seq < st.next) {
        st.buffer.delete(seq);
        continue;
      }
      const { messageData, viaServer } = st.buffer.get(seq);
      st.buffer.delete(seq);
      st.next = seq + 1;
      this.#dispatchOrdered(st.fromUserId, st.fromSessionId, messageData, viaServer);
    }
  }

  /**
   * 状态表容量治理：清理空闲条目（无缓存消息且无等待定时器）。
   * 清理后该流重建时以首见序号为基线，序号仍单调，不影响后续保序。
   */
  #pruneOrderStates() {
    for (const [key, st] of this.#orderStates) {
      if (st.buffer.size === 0 && !st.timer) {
        this.#orderStates.delete(key);
      }
    }
  }

  /**
   * 有序消息的实际分发：__app 服务消息路由到 ServiceRegistry，
   * 其余派发给对应 RemoteUser 的 message 事件
   */
  #dispatchOrdered(fromUserId, fromSessionId, messageData, viaServer) {
    // 3. 检查是否为 app 绑定消息
    if (
      messageData &&
      typeof messageData === "object" &&
      !Array.isArray(messageData) &&
      messageData.__app
    ) {
      this.#dispatchToServiceApp(fromUserId, fromSessionId, messageData);
      return;
    }

    // 4. 确保 RemoteUser 存在后分发给对应实例
    this.#ensureRemoteUser(fromUserId, "remote")
      .then((remoteUser) => {
        remoteUser._trigger("message", {
          fromUserId,
          fromSessionId,
          data: messageData,
          viaServer,
        });
      })
      .catch(() => {});
  }

  /**
   * 处理对端主动广播的服务上/下线消息，
   * 更新对应 RemoteUser 的 serviceSessionCache 并唤醒等待者
   */
  async #handleServiceAvailability(fromUserId, fromSessionId, appId, available) {
    if (!appId) return;
    try {
      const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");
      remoteUser._handleServiceAvailability(appId, fromSessionId, available);
    } catch {
      // 无法建立 RemoteUser 时静默丢弃
    }
  }

  /**
   * 响应对方发起的 service 查询：回复本地所有已注册 appId 列表
   * 通过缓存的 RemoteUser 发送回复，确保路径一致
   */
  async #handleServiceQuery(fromUserId, fromSessionId, query) {
    const services = this.#serviceRegistry.getServiceList();
    try {
      const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");
      await remoteUser.send(fromSessionId, {
        type: "__service_response",
        id: query.id,
        services,
      }, true); // raw=true 跳过 E2EE
    } catch {
      // 失败静默
    }
  }

  /**
   * 处理入站 __storage_req：三道防线校验后以只读方式执行，回传 __storage_resp
   *
   * 防线依次为：
   * 1. name 必须以 "share:" 开头（约定前缀，其余空间一律不可见）
   * 2. name 必须已通过 shareStorage() 显式开启（登记表校验）
   * 3. op 必须在只读白名单内（写操作一律拒绝）
   *
   * resp 格式：{ type: "__storage_resp", reqId, ok, value? , error?: { code, message } }
   * 错误码：invalid_name / not_shared / read_only / too_large / internal
   *
   * @param {string} fromUserId
   * @param {string} fromSessionId
   * @param {Object} req - { reqId, name, op, key }
   */
  async #handleStorageRequest(fromUserId, fromSessionId, req) {
    const { reqId, name, op, key } = req;

    const respond = async (ok, payload) => {
      try {
        let resp = { type: "__storage_resp", reqId, ok, ...payload };
        // 大小防线：测量实际要序列化发送的字节数，超限改回 too_large
        if (resp.ok) {
          const size = new TextEncoder().encode(
            JSON.stringify(resp),
          ).length;
          if (size > SHARED_STORAGE_RESP_MAX_BYTES) {
            resp = {
              type: "__storage_resp",
              reqId,
              ok: false,
              error: {
                code: "too_large",
                message: `storage response too large (${size} bytes, max ${SHARED_STORAGE_RESP_MAX_BYTES})`,
              },
            };
          }
        }
        const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");
        await remoteUser.send(fromSessionId, resp, true);
      } catch {
        // 对端离线等回传失败，静默丢弃
      }
    };

    // 第一道防线：约定前缀
    if (typeof name !== "string" || !name.startsWith("share:")) {
      await respond(false, {
        error: {
          code: "invalid_name",
          message: 'shared storage name must start with "share:"',
        },
      });
      return;
    }

    // 第二道防线：必须已显式开启
    let sharedList;
    try {
      sharedList = await getSharedStorages(this.#namespace);
    } catch {
      await respond(false, {
        error: {
          code: "internal",
          message: "failed to read shared storage registry",
        },
      });
      return;
    }
    if (!sharedList.includes(name)) {
      await respond(false, {
        error: {
          code: "not_shared",
          message: `storage "${name}" is not shared`,
        },
      });
      return;
    }

    // 第三道防线：只读白名单
    if (
      typeof op !== "string" ||
      !SHARED_STORAGE_READ_OPS.includes(op)
    ) {
      await respond(false, {
        error: {
          code: "read_only",
          message: `operation "${op}" is not allowed (shared storage is read-only)`,
        },
      });
      return;
    }

    // 只读执行并回传
    try {
      const storage = await this.getStorage(name);
      let value;
      if (op === "length") {
        value = await storage.length;
      } else if (op === "keys" || op === "entries") {
        // 异步生成器，收集为数组后回传
        const out = [];
        for await (const item of storage[op]()) {
          out.push(item);
        }
        value = out;
      } else {
        value = await storage[op](key);
      }
      await respond(true, { value });
    } catch (err) {
      await respond(false, {
        error: {
          code: "internal",
          message: String(err?.message || err),
        },
      });
    }
  }

  /**
   * 将 __app 消息分发给 ServiceRegistry 中注册的 handler
   *
   * 携带 __env 信封的消息（新版对端发出）由核心层处理可靠投递：
   * - 按 (fromUserId|msgId) 去重，重发不会重复执行 handler，但会补发 ACK；
   * - handler 执行完毕（含返回的 Promise settle）后自动回 __ack；
   * - 未注册 appId 时回 error: "no_handler" 的 ACK，让发送方立刻失败而非干等超时。
   *
   * 未携带 __env 的消息（旧版对端发出）保持原行为：去重与 ACK 均不参与。
   *
   * 未注册对应 appId 时不会直接丢弃业务信息，而是触发本地
   * `unhandled_service_message` 事件供调试/兜底逻辑使用。
   */
  async #dispatchToServiceApp(fromUserId, fromSessionId, messageData) {
    const appId = messageData.__app;
    const data = messageData.__data;
    const env = messageData.__env;
    const handler = this.#serviceRegistry.getHandler(appId);

    // 核心层去重：重复投递（发送方重发且原 ACK 丢失）不再执行 handler，
    // 但必须补发 ACK，让发送方的重试循环停下来
    if (env?.msgId && !this.#msgDedup.check(`${fromUserId}|${env.msgId}`)) {
      await this.#sendServiceAck(fromUserId, fromSessionId, env.msgId, {
        ok: true,
        duplicate: true,
      });
      return;
    }

    if (!handler) {
      // 触发本地事件，便于观测并支持业务侧兜底处理
      this._trigger("unhandled_service_message", {
        appId,
        fromUserId,
        fromSessionId,
        data,
      });
      if (env?.msgId) {
        await this.#sendServiceAck(fromUserId, fromSessionId, env.msgId, {
          ok: false,
          error: "no_handler",
        });
      }
      return;
    }

    // 获取或创建 RemoteUser 供 ctx 使用
    const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");

    const ctx = {
      fromUserId,
      fromSessionId,
      remoteUser,
    };

    // 大 payload 拉取化：去重之后、handler 之前，从发送方拉取分块并还原。
    // 拉取失败回 pull_failed 的确定性 ACK，发送方立即失败而非等超时
    let finalData = data;
    if (messageData.__pull?.fileHash) {
      try {
        finalData = await this.#fetchLargePayload(fromUserId, messageData.__pull);
      } catch (err) {
        console.warn(
          `[ServiceRegistry] Large payload pull failed for "${appId}":`,
          err,
        );
        if (env?.msgId) {
          await this.#sendServiceAck(fromUserId, fromSessionId, env.msgId, {
            ok: false,
            error: "pull_failed",
            message: String(err?.message || err),
          });
        }
        return;
      }
    }

    let handlerError = null;
    try {
      // 等待 handler 完成（含异步 Promise）——ACK 语义 = "handler 已执行完"
      const returned = handler(finalData, ctx);
      if (returned && typeof returned.then === "function") {
        await returned;
      }
    } catch (err) {
      handlerError = err;
      console.warn(`[ServiceRegistry] Handler error for "${appId}":`, err);
    }

    if (env?.msgId) {
      await this.#sendServiceAck(
        fromUserId,
        fromSessionId,
        env.msgId,
        handlerError
          ? { ok: false, error: "handler_error" }
          : { ok: true },
      );
    }
  }

  /**
   * 获取（惰性创建并启动的）大 payload 拉取发布器。
   * 复用 nos/publish 的内容寻址分块机制：发送方 publish，接收方 fetchFile。
   * 动态导入避免 nos/user ↔ nos/publish 循环依赖。
   * @returns {Promise<import("../publish/data-publisher.js").DataPublisher>}
   */
  async _getDataPublisher() {
    if (!this.#dataPublisher) {
      const { DataPublisher } = await import("../publish/data-publisher.js");
      this.#dataPublisher = new DataPublisher(this);
      this.#dataPublisher.start();
    }
    return this.#dataPublisher;
  }

  /**
   * 拉取大 payload 并还原为原始数据（接收端，阶段三第 9 步）。
   *
   * 发送方超过阈值的 __app 数据不再内联在消息里，而是内容寻址发布后
   * 在消息中携带 `{__pull: {fileHash, encrypted}}`；本方法用 DataPublisher
   * 从发送方拉取分块、组装、（可选）解密，再 JSON.parse 还原。
   *
   * @param {string} fromUserId - 发送方 userId（拉取对端）
   * @param {{fileHash: string, encrypted?: boolean}} pull - 拉取引用
   * @returns {Promise<*>} 还原后的原始数据
   */
  async #fetchLargePayload(fromUserId, pull) {
    const publisher = await this._getDataPublisher();
    const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");
    // fetchFile 返回 { blob, fileName, fileSize }
    const result = await publisher.fetchFile(remoteUser, pull.fileHash);
    let bytes = new Uint8Array(await result.blob.arrayBuffer());
    if (pull.encrypted) {
      const { tryDecryptBytes } = await import("../crypto/crypto-e2ee.js");
      const plain = await tryDecryptBytes(this, fromUserId, bytes);
      if (!plain) {
        throw new Error("large payload decrypt failed");
      }
      bytes = plain;
    }
    // 剥掉发布时的 0x00 标记前缀（明文/密文均有，见 remote-user.js #publishLargePayload）
    if (bytes[0] === 0) {
      bytes = bytes.slice(1);
    }
    return JSON.parse(new TextDecoder().decode(bytes));
  }

  /**
   * 回发 __ack（raw，不做 E2EE）：告知发送方 msgId 的处理结果。
   * 回发失败静默——发送方会走 ACK 超时路径。
   */
  async #sendServiceAck(fromUserId, fromSessionId, msgId, payload) {
    try {
      const remoteUser = await this.#ensureRemoteUser(fromUserId, "remote");
      await remoteUser.send(
        fromSessionId,
        { type: "__ack", msgId, ...payload },
        true,
      );
    } catch {
      // 对端不可达时静默丢弃
    }
  }

  /**
   * 获取用户的命名空间
   */
  get namespace() {
    return this.#namespace;
  }

  /**
   * 获取会话 ID
   */
  get sessionId() {
    return this.#sessionId;
  }

  /**
   * 获取凭证管理器（统一入口：个人资料 profile 与证书共用同一实例与存储）
   */
  get cred() {
    return this.#cred;
  }

  /**
   * 获取服务器管理器
   */
  get server() {
    return this.#server;
  }

  /**
   * 获取 RTC 管理器
   */
  get rtc() {
    return this.#rtc;
  }

  /**
   * 获取流量记录器
   */
  get traffic() {
    return this.#traffic;
  }

  /**
   * 获取当前已连接成功的 RemoteUser 列表
   * 包含主动 connectUser 成功的用户，以及收到消息后被动创建 RemoteUser 的用户
   * 返回数组快照，避免外部修改内部缓存
   * @returns {RemoteUser[]}
   */
  get remoteUsers() {
    const users = [];
    for (const entry of this.#remoteUserCache.values()) {
      if (entry instanceof RemoteUser) {
        users.push(entry);
      }
    }
    return Object.freeze(users);
  }

  /**
   * 注册一个应用服务
   *
   * 注册后，对方可以通过 remoteUser.sendToService(appId, data) 发送数据，
   * 收到的消息会自动路由到 onMessage 回调。
   *
   * @param {string} appId - 应用唯一标识
   * @param {Object} [options]
   * @param {boolean} [options.exposeToServer=false] - 是否将 appId 暴露给服务端
   * @param {Function} [options.onMessage] - (data, ctx) => {} 收到的应用消息
   * @returns {{ appId: string, unregister: () => void }}
   */
  registerService(appId, options = {}) {
    return this.#serviceRegistry.register(appId, options);
  }

  /**
   * 准备用户实例，从数据库获取密钥对，如果不存在则生成并保存
   * 使用 Promise 缓存防止并发初始化导致密钥不一致
   * @returns {Promise}
   */
  async ready() {
    if (this.userId) {
      return this;
    }

    // 检查是否已有该 namespace 的初始化 Promise
    let initPromise = initPromises.get(this.#namespace);

    if (!initPromise) {
      // 创建新的初始化 Promise
      initPromise = (async () => {
        let keys = await getUserKeys(this.#namespace);
        let isNewUser = false;
        if (!keys) {
          // 数据库中没有密钥，生成新的密钥对
          keys = await generateKeyPair();
          await saveUserKeys(this.#namespace, keys);
          isNewUser = true;
        }
        return { keys, isNewUser };
      })();

      initPromises.set(this.#namespace, initPromise);

      // 初始化完成后清理缓存，允许后续重新初始化
      initPromise.finally(() => {
        initPromises.delete(this.#namespace);
      });
    }

    // 等待初始化完成并获取密钥
    const { keys, isNewUser } = await initPromise;

    // 调用父类的 init 以完成其余的初始化逻辑（如计算哈希、生成签名/验证函数等）
    await super.init(keys);

    // 如果是新用户，生成默认用户名并保存
    if (isNewUser) {
      const defaultUsername =
        "user-" + Math.random().toString(36).substring(2, 10);
      await this.updateInfo({ username: defaultUsername });
    }

    // 启动个人资料（profile）交换监听
    this.#cred.start();

    // 自动连接默认服务器列表，不阻塞 ready()
    this.#server.connectAll().catch(() => {});

    return this;
  }

  /**
   * 获取该用户专属的存储空间
   *
   * 底层复用 nos/storage，存储 id 为 `user:<namespace>:<userId>:<name>`，
   * 每个「本地用户 + 身份 + 子空间」对应独立的 IndexedDB 数据库，天然隔离：
   * 不同用户、同一用户不同身份之间互不可见。
   *
   * 创建时会自动登记到用户库，deleteUser 时联动清理。
   * @param {string} [name] - 业务子空间名，默认 "default"
   * @returns {Promise<NosStorage>}
   */
  async getStorage(name = "default") {
    await this.ready();
    const id = `user:${this.#namespace}:${this.userId}:${name}`;
    await addUserStorageId(this.#namespace, id);
    return getGlobalStorage(id);
  }

  /**
   * 显式开启一个存储空间的共享（只读），供远端用户读取。
   *
   * 仅允许以 `share:` 开头的子空间名参与共享，其余存储不会被远端访问；
   * 开启后所有已连接用户都能读取该空间，返回的 revoke 函数可随时关闭共享。
   *
   * 注意：共享的是「读取」能力，远端无法写入；本方法不创建存储，
   * 数据仍由本地 getStorage("share:xxx") 维护。
   *
   * @param {string} name - 存储空间名，必须以 "share:" 开头
   * @returns {Promise<() => Promise<void>>} revoke 函数：调用后关闭该空间的共享
   */
  async shareStorage(name) {
    await this.ready();
    if (!name || !name.startsWith("share:")) {
      throw new Error('shareStorage name must start with "share:"');
    }
    await addSharedStorage(this.#namespace, name);
    return async () => {
      await removeSharedStorage(this.#namespace, name);
    };
  }

  /**
   * 更新用户信息
   * 合并现有信息，签名后存储到数据库，并推送给已建立通信的远端用户
   *
   * 用户信息即个人资料（profile，旧称名片）的签名载荷：以 role="profile"
   * 的自签证书形态产出，与证书共用同一数据模型（存储时按 cert 规则生成 id
   * 入 certs store）
   * @param {Object} data - 需要更新的用户信息字段
   * @returns {Promise<Object>} 更新后的签名用户信息
   */
  async updateInfo(data) {
    // 获取现有信息
    const existingInfo = (await getUserInfo(this.#namespace)) || {};

    // 合并数据，移除签名相关字段后重新签名；
    // 同时剥掉旧形态可能遗留的 userId（历史兼容字段，统一形态用 subject 标识持有者）
    const {
      signTime,
      publicKey,
      signature,
      userId: _legacyUserId,
      ...pureExistingInfo
    } = existingInfo;
    const mergedData = {
      ...pureExistingInfo,
      ...data,
      role: PROFILE_ROLE,
      issuer: this.userId,
      subject: this.userId,
    };

    // 签名数据
    const signedData = await this._sign(mergedData);

    // 保存到数据库
    await saveUserInfo(this.#namespace, signedData);

    return signedData;
  }

  /**
   * 获取用户信息
   * @returns {Promise<Object | null>} 已签名的用户信息
   */
  async getInfo() {
    return getUserInfo(this.#namespace);
  }

  /**
   * 确保指定 userId 已创建 RemoteUser 并加入缓存。
   * 如果是新加入的，触发 remote_user_connected 事件。
   * @param {string} userId
   * @param {"local"|"remote"} initiatedBy
   * @returns {Promise<RemoteUser>}
   */
  #ensureRemoteUser(userId, initiatedBy = "remote") {
    if (this.#remoteUserCache.has(userId)) {
      return Promise.resolve(this.#remoteUserCache.get(userId));
    }

    const remoteUser = new RemoteUser(userId, this);
    this.#remoteUserCache.set(userId, remoteUser);
    this.#triggerRemoteUserConnected(userId, remoteUser, initiatedBy);
    return Promise.resolve(remoteUser);
  }

  /**
   * 内部接口：供管理器确保 RemoteUser 存在。
   * @param {string} userId
   * @param {"local"|"remote"} initiatedBy
   * @returns {Promise<RemoteUser>}
   */
  _ensureRemoteUser(userId, initiatedBy = "remote") {
    return this.#ensureRemoteUser(userId, initiatedBy);
  }

  #triggerRemoteUserConnected(userId, remoteUser, initiatedBy) {
    this._trigger("remote_user_connected", {
      userId,
      remoteUser,
      initiatedBy,
    });
  }

  #triggerRemoteUserDisconnected(userId, remoteUser, reason, error) {
    this._trigger("remote_user_disconnected", {
      userId,
      remoteUser,
      reason,
      error,
    });
  }

  /**
   * 连接远程用户，返回对应的 RemoteUser 实例
   * 会查询已连接的服务器确认对方是否在线
   * @param {string} userId - 目标用户的 userId
   * @returns {Promise<RemoteUser>}
   */
  async connectUser(userId) {
    if (!userId) {
      throw new Error("userId is required");
    }

    // 已有缓存（进行中的 Promise 或已完成的 RemoteUser）
    if (this.#remoteUserCache.has(userId)) {
      return this.#remoteUserCache.get(userId);
    }

    // 发起连接，Promise 存入缓存，并发调用复用同一 Promise
    const promise = this.#doConnectUser(userId)
      .then((remoteUser) => {
        if (this.#remoteUserCache.get(userId) === promise) {
          this.#remoteUserCache.set(userId, remoteUser);
          this.#triggerRemoteUserConnected(userId, remoteUser, "local");
        }
        return remoteUser;
      })
      .catch((error) => {
        if (this.#remoteUserCache.get(userId) === promise) {
          this.#remoteUserCache.delete(userId);
          this.#triggerRemoteUserDisconnected(userId, null, "error", error);
        }
        throw new Error(`User ${userId} is not online on any connected server`);
      });

    this.#remoteUserCache.set(userId, promise);
    return promise;
  }

  async #doConnectUser(userId) {
    // 使用共享算法查询目标用户在线的服务器（按综合延迟排序）
    // 因并发握手/状态同步可能存在短暂窗口，这里做少量重试
    let bestServer = null;
    const maxRetries = 5;
    for (let i = 0; i < maxRetries; i++) {
      bestServer = await this.#server.findBestServer(userId);
      if (bestServer) break;
      if (i < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, 200));
      }
    }
    if (!bestServer) {
      throw new Error(`User ${userId} is not online on any connected server`);
    }
    const remoteUser = new RemoteUser(userId, this);
    return remoteUser;
  }

  /**
   * 断开与远程用户的连接
   * 清理本地缓存并触发 remote_user_disconnected 事件
   * @param {string} userId - 目标用户的 userId
   */
  async disconnectUser(userId) {
    const cached = this.#remoteUserCache.get(userId);
    if (!cached) return;

    const remoteUser = await Promise.resolve(cached).catch(() => null);
    this.#remoteUserCache.delete(userId);
    if (remoteUser) {
      // 先 dispose RemoteUser（清内部状态/定时器），再断底层 PC 资源
      // 顺序：dispose 不依赖 PC；disconnectAllForUser 触发的 rtc_state(disconnected)
      // 回调到已 dispose 的 RemoteUser 时 _handleRTCStateChange 仍是安全的（只做 delete）
      remoteUser.dispose();
      this.#rtc.disconnectAllForUser(userId);
      this.#triggerRemoteUserDisconnected(userId, remoteUser, "manual");
    } else {
      // remoteUser 为 null（之前连接失败），仍需清理可能残留的 PC 资源
      this.#rtc.disconnectAllForUser(userId);
    }
  }

  /**
   * 查询指定 userId 当前是否在线
   * 已缓存用户通过 RemoteUser.getSessionIds() 判断；未缓存用户直接查询已连接服务器
   * @param {string} userId - 目标用户的 userId
   * @returns {Promise<boolean>}
   */
  async isRemoteUserOnline(userId) {
    if (!userId) {
      throw new Error("userId is required");
    }

    if (this.#remoteUserCache.has(userId)) {
      const remoteUser = await Promise.resolve(this.#remoteUserCache.get(userId));
      const sessions = await remoteUser.getSessionIds();
      return sessions.length > 0;
    }

    const urls = this.#server.connectedUrls;
    for (const url of urls) {
      try {
        const result = await this.#server.queryUserOnline(url, userId);
        if (result.online) return true;
      } catch {
        // 继续尝试其他服务器
      }
    }
    return false;
  }

  /**
   * 获取当前已缓存的 RemoteUser 列表
   * @param {Object} [options]
   * @param {boolean} [options.onlineOnly=false] - 为 true 时过滤掉当前不在线的用户
   * @returns {Promise<RemoteUser[]>}
   */
  async getRemoteUsers(options = {}) {
    const { onlineOnly = false } = options || {};
    const users = this.remoteUsers;
    if (!onlineOnly) return users.slice();

    const results = await Promise.allSettled(
      users.map(async (remoteUser) => {
        const sessions = await remoteUser.getSessionIds();
        return sessions.length > 0 ? remoteUser : null;
      }),
    );

    return results
      .filter((r) => r.status === "fulfilled" && r.value)
      .map((r) => r.value);
  }

  /**
   * 获取同一 namespace 下所有标签页的 sessionId 列表
   * 通过 BroadcastChannel 实现跨标签页通信，无需经过服务器
   * 每个 LocalUser 实例在构造时已注册持久化监听器，会自动回复其他实例的查询
   * @param {number} [timeout=100] - 等待其他标签页响应的超时时间（毫秒）
   * @returns {Promise<string[]>} 包含自身在内的所有活跃 sessionId 列表
   */
  async getSessionIds(timeout = 1000) {
    return new Promise((resolve) => {
      const sessions = new Set();
      // 包含自己的 sessionId
      sessions.add(this.#sessionId);

      const handler = (event) => {
        if (event.data.type === "session-response") {
          // 收集其他标签页的 sessionId
          sessions.add(event.data.sessionId);
        }
      };

      this.#sessionChannel.addEventListener("message", handler);

      // 广播 announce，询问其他标签页
      this.#sessionChannel.postMessage({ type: "session-announce" });

      // 超时后返回收集到的结果
      setTimeout(() => {
        this.#sessionChannel.removeEventListener("message", handler);
        resolve([...sessions]);
      }, timeout);
    });
  }
}
